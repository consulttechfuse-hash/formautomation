import { NextResponse } from 'next/server'
import { Resend } from 'resend'
import { createClient } from '@supabase/supabase-js'

const resend = new Resend(process.env.RESEND_API_KEY)
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: Request) {
  try {
    const { email, adminId } = await request.json()
    
    // Check if user already exists
    const { data: existingUser } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('email', email)
      .single()
    
    if (existingUser) {
      // Update existing user to agent role
      await supabaseAdmin
        .from('users')
        .update({ role: 'agent', admin_id: adminId })
        .eq('id', existingUser.id)
    } else {
      // Create new user via auth admin
      const { data: newUser, error } = await supabaseAdmin.auth.admin.createUser({
        email: email,
        email_confirm: true,
        user_metadata: { role: 'agent' }
      })
      
      if (error) throw error
      
      if (newUser.user) {
        await supabaseAdmin
          .from('users')
          .update({ role: 'agent', admin_id: adminId })
          .eq('id', newUser.user.id)
      }
    }
    
    // Send invitation email
    await resend.emails.send({
      from: 'Techfuse Admin <noreply@reply.techfuseconsult.online>',
      to: email,
      subject: 'You have been invited as an Agent',
      html: `
        <h2>Agent Invitation</h2>
        <p>You have been invited to join Techfuse DocControl as an Agent.</p>
        <p>Click the link below to set your password and sign in:</p>
        <a href="${process.env.NEXT_PUBLIC_APP_URL}/reset-password">Set Your Password</a>
        <p>After setting your password, you will have access to the Agent Dashboard.</p>
      `
    })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Invite error:', error)
    return NextResponse.json({ error: 'Failed to send invite' }, { status: 500 })
  }
}

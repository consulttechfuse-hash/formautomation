import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

export async function GET() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const { data, error } = await supabase
    .from('unlock_requests')
    .select(`
      *,
      agent:requested_by(email),
      client:client_id(email, fn_t1, srn_t1)
    `)
    .eq('status', 'pending')
    .order('created_at', { ascending: false })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  const formatted = (data || []).map(req => ({
    ...req,
    agent_email: req.agent?.email,
    client_email: req.client?.email,
    client_name: `${req.client?.fn_t1 || ''} ${req.client?.srn_t1 || ''}`.trim()
  }))

  return NextResponse.json(formatted)
}

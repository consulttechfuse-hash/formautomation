'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

type Client = {
  id: string
  email: string
  fn_t1?: string
  srn_t1?: string
  idp_t1?: string
  has_consented: boolean
  has_paid: boolean
  onboarding_complete: boolean
  onboarding_submitted: boolean
  admin_id: string | null
  created_at: string
}

const formOptions = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]

export default function AgentDashboard() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'clients' | 'requests'>('dashboard')
  const [allClients, setAllClients] = useState<Client[]>([])
  const [clients, setClients] = useState<Client[]>([])
  const [searchTerm, setSearchTerm] = useState<string>('')
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [selectedForm, setSelectedForm] = useState<number>(2)
  const [viewFormData, setViewFormData] = useState<{ html: string; clientName: string; formNumber: number } | null>(null)
  const [unlockReason, setUnlockReason] = useState('')
  const [showUnlockModal, setShowUnlockModal] = useState(false)
  const [selectedClientForUnlock, setSelectedClientForUnlock] = useState<Client | null>(null)
  const [unlockRequests, setUnlockRequests] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [agentName, setAgentName] = useState('')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    checkAuthAndFetchData()
  }, [filterStatus, searchTerm])

  async function checkAuthAndFetchData() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase.from('users').select('role, admin_id, email').eq('id', user.id).single()
    if (profile?.role !== 'agent') {
      router.push('/client/dashboard')
      return
    }

    setAgentName(profile.email)

    const { data: clientsData } = await supabase.from('users').select('*').eq('role', 'client').eq('admin_id', profile.admin_id).order('created_at', { ascending: false })
    const clientsWithFormData = await Promise.all((clientsData || []).map(async (client) => {
      const { data: form01 } = await supabase.from('form01_data').select('fn_t1, srn_t1, idp_t1').eq('user_id', client.id).single()
      return { ...client, fn_t1: form01?.fn_t1 || '', srn_t1: form01?.srn_t1 || '', idp_t1: form01?.idp_t1 || '' }
    }))
    setAllClients(clientsWithFormData)
    filterClients(clientsWithFormData)

    const { data: requests } = await supabase.from('unlock_requests').select('*').eq('requested_by', user.id).order('created_at', { ascending: false })
    setUnlockRequests(requests || [])
    setLoading(false)
  }

  async function handleSignOut() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  function filterClients(data = allClients) {
    let filtered = [...data]
    if (filterStatus === 'paid') filtered = filtered.filter(c => c.has_paid === true)
    else if (filterStatus === 'non_paid') filtered = filtered.filter(c => c.has_paid === false)
    else if (filterStatus === 'consented') filtered = filtered.filter(c => c.has_consented === true)
    else if (filterStatus === 'forms_submitted') filtered = filtered.filter(c => c.onboarding_submitted === true)
    if (searchTerm.trim() !== '') {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(c => c.email.toLowerCase().includes(term) || (c.fn_t1 && c.fn_t1.toLowerCase().includes(term)) || (c.srn_t1 && c.srn_t1.toLowerCase().includes(term)) || (c.idp_t1 && c.idp_t1.toLowerCase().includes(term)))
    }
    setClients(filtered)
  }

  async function viewClientForm(client: Client, formNumber: number) {
    let { data: formData } = await supabase.from('generated_forms').select('filled_html').eq('user_id', client.id).eq('form_number', formNumber).single()
    if (!formData?.filled_html) {
      const { data: template } = await supabase.from('form_templates').select('template_html').eq('form_number', formNumber).single()
      if (template?.template_html) {
        let html = template.template_html
        const { data: form01 } = await supabase.from('form01_data').select('*').eq('user_id', client.id).single()
        if (form01) {
          Object.keys(form01).forEach(key => { const regex = new RegExp(`{{${key}}}`, 'g'); html = html.replace(regex, form01[key] || '') })
        }
        const fullName = `${client.fn_t1 || ''} ${client.srn_t1 || ''}`.trim()
        html = html.replace(/{{full_name}}/g, fullName).replace(/{{current_date}}/g, new Date().toLocaleDateString()).replace(/{{current_year}}/g, new Date().getFullYear().toString()).replace(/{{current_month}}/g, (new Date().getMonth() + 1).toString()).replace(/{{current_day}}/g, new Date().getDate().toString())
        formData = { filled_html: html }
      }
    }
    if (formData?.filled_html) {
      setViewFormData({ html: formData.filled_html, clientName: `${client.fn_t1 || ''} ${client.srn_t1 || ''}`.trim() || client.email, formNumber: formNumber })
    } else {
      alert(`Form ${formNumber} not available for this client.`)
    }
  }

  function requestUnlock(client: Client) {
    setSelectedClientForUnlock(client)
    setUnlockReason('')
    setShowUnlockModal(true)
  }

  async function submitUnlockRequest() {
    if (!selectedClientForUnlock || !unlockReason) {
      alert('Please provide a reason for the unlock request')
      return
    }

    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { error } = await supabase.from('unlock_requests').insert({
      client_id: selectedClientForUnlock.id,
      requested_by: user.id,
      reason: unlockReason,
      form_number: selectedForm,
      status: 'pending'
    })

    if (error) {
      alert('Error submitting request: ' + error.message)
    } else {
      alert(`Unlock request submitted for ${selectedClientForUnlock.email} - Form ${selectedForm}`)
      setShowUnlockModal(false)
      setSelectedClientForUnlock(null)
      setUnlockReason('')
      // Refresh requests list
      const { data: requests } = await supabase.from('unlock_requests').select('*').eq('requested_by', user.id).order('created_at', { ascending: false })
      setUnlockRequests(requests || [])
    }
  }

  if (loading) return <div className="text-center py-10">Loading dashboard...</div>

  return (
    <div className="flex h-screen bg-gray-100">
      {/* View Form Modal */}
      {viewFormData && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center p-4 border-b"><h2 className="text-xl font-bold">Form {String(viewFormData.formNumber).padStart(2, '0')}</h2><p className="text-sm text-gray-500">Client: {viewFormData.clientName}</p><button onClick={() => setViewFormData(null)} className="text-gray-500 hover:text-gray-700 text-2xl">&times;</button></div>
            <div className="flex-1 overflow-y-auto p-6 bg-gray-50"><div className="bg-white rounded-lg shadow-sm p-6"><div dangerouslySetInnerHTML={{ __html: viewFormData.html }} /></div></div>
          </div>
        </div>
      )}

      {/* Unlock Request Modal */}
      {showUnlockModal && selectedClientForUnlock && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b"><h2 className="text-xl font-bold">Request Form Unlock</h2><button onClick={() => setShowUnlockModal(false)} className="text-gray-500 hover:text-gray-700 text-2xl">&times;</button></div>
            <div className="p-4">
              <p><strong>Client:</strong> {selectedClientForUnlock.email}</p>
              <p><strong>Name:</strong> {selectedClientForUnlock.fn_t1} {selectedClientForUnlock.srn_t1}</p>
              <p><strong>Form to unlock:</strong> {selectedForm}</p>
              <div className="mb-4"><label className="block text-sm font-medium text-gray-700 mb-1">Reason for unlock request</label><textarea value={unlockReason} onChange={(e) => setUnlockReason(e.target.value)} placeholder="Explain why this client needs their forms unlocked..." className="w-full border rounded-lg px-3 py-2" rows={3} required /></div>
              <div className="flex justify-end gap-3"><button onClick={() => setShowUnlockModal(false)} className="px-4 py-2 border rounded">Cancel</button><button onClick={submitUnlockRequest} className="px-4 py-2 bg-yellow-600 text-white rounded">Submit Request</button></div>
            </div>
          </div>
        </div>
      )}

      {/* Left Sidebar */}
      <div className="w-64 bg-white shadow-md flex flex-col">
        <div className="p-4 border-b"><h1 className="text-xl font-bold">Agent Panel</h1><p className="text-sm text-gray-500">{agentName}</p></div>
        <nav className="flex-1 p-2">
          <button onClick={() => setActiveTab('dashboard')} className={`w-full text-left px-4 py-2 rounded-lg mb-1 ${activeTab === 'dashboard' ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'}`}>📊 Dashboard</button>
          <button onClick={() => setActiveTab('clients')} className={`w-full text-left px-4 py-2 rounded-lg mb-1 ${activeTab === 'clients' ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'}`}>👥 Clients</button>
          <button onClick={() => setActiveTab('requests')} className={`w-full text-left px-4 py-2 rounded-lg mb-1 ${activeTab === 'requests' ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'}`}>📋 My Requests</button>
        </nav>
        <div className="p-4 border-t"><button onClick={handleSignOut} className="w-full bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600">Sign Out</button></div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {activeTab === 'dashboard' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Dashboard</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-blue-500 text-white rounded-lg p-6"><div className="text-sm opacity-90">Total Clients</div><div className="text-4xl font-bold">{allClients.length}</div></div>
              <div className="bg-yellow-500 text-white rounded-lg p-6"><div className="text-sm opacity-90">Pending Requests</div><div className="text-4xl font-bold">{unlockRequests.filter(r => r.status === 'pending').length}</div></div>
            </div>
          </div>
        )}

        {activeTab === 'clients' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Clients</h2>
            <div className="bg-white rounded-lg shadow mb-4 p-4">
              <div className="flex flex-wrap gap-4">
                <input type="text" placeholder="Search by name, email, or ID..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="flex-1 border rounded-lg px-4 py-2" />
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="border rounded px-3 py-2"><option value="all">All Clients</option><option value="paid">Paid Only</option><option value="non_paid">Non-Paying</option><option value="consented">Consented</option><option value="forms_submitted">Submitted</option></select>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <table className="w-full"><thead className="bg-gray-50"><tr><th className="px-4 py-2 text-left">Name</th><th className="px-4 py-2 text-left">Email</th><th className="px-4 py-2 text-left">ID/Passport</th><th className="px-4 py-2 text-left">Form</th><th className="px-4 py-2 text-left">Actions</th></tr></thead>
              <tbody>{clients.map((client) => (<tr key={client.id} className="border-t"><td className="px-4 py-2">{client.fn_t1 || '-'} {client.srn_t1 || '-'}</td><td className="px-4 py-2">{client.email}</td><td className="px-4 py-2">{client.idp_t1 || '-'}</td><td className="px-4 py-2"><select value={selectedForm} onChange={(e) => setSelectedForm(parseInt(e.target.value))} className="border rounded px-2 py-1 text-sm">{formOptions.map(n => <option key={n} value={n}>Form {n}</option>)}</select></td><td className="px-4 py-2"><div className="flex gap-2"><button onClick={() => viewClientForm(client, selectedForm)} className="bg-blue-600 text-white px-3 py-1 rounded text-sm">View</button><button onClick={() => requestUnlock(client)} className="bg-yellow-600 text-white px-3 py-1 rounded text-sm">Request Unlock</button></div></td></tr>))}</tbody></table>
              {clients.length === 0 && <div className="text-center py-8 text-gray-500">No clients found</div>}
            </div>
          </div>
        )}

        {activeTab === 'requests' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">My Unlock Requests</h2>
            {unlockRequests.length === 0 ? (<div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">No unlock requests submitted</div>) : (
              <div className="bg-white rounded-lg shadow overflow-hidden">
                <table className="w-full"><thead className="bg-gray-50"><tr><th className="px-4 py-2 text-left">Client</th><th className="px-4 py-2 text-left">Form</th><th className="px-4 py-2 text-left">Reason</th><th className="px-4 py-2 text-left">Status</th><th className="px-4 py-2 text-left">Submitted</th></tr></thead>
                <tbody>{unlockRequests.map(req => (<tr key={req.id} className="border-t"><td className="px-4 py-2">{req.client_id}</td><td className="px-4 py-2">Form {req.form_number}</td><td className="px-4 py-2">{req.reason}</td><td className="px-4 py-2"><span className={`px-2 py-1 rounded text-xs ${req.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : req.status === 'approved' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{req.status}</span></td><td className="px-4 py-2">{new Date(req.created_at).toLocaleDateString()}</td></tr>))}</tbody></table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

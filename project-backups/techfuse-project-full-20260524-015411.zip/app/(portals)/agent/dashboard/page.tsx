'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

type Client = {
  id: string
  email: string
  has_consented: boolean
  has_paid: boolean
  onboarding_complete: boolean
  onboarding_submitted: boolean
  created_at: string
}

export default function AgentDashboard() {
  const [clients, setClients] = useState<Client[]>([])
  const [selectedClient, setSelectedClient] = useState<Client | null>(null)
  const [unlockReason, setUnlockReason] = useState('')
  const [showUnlockModal, setShowUnlockModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [agentName, setAgentName] = useState('')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    checkAuthAndFetchData()
  }, [])

  async function checkAuthAndFetchData() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('users')
      .select('role, admin_id, email')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'agent') {
      router.push('/client/dashboard')
      return
    }

    setAgentName(profile.email)

    // Get clients under the same admin
    const { data: clientsData } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'client')
      .eq('admin_id', profile.admin_id)
      .order('created_at', { ascending: false })

    setClients(clientsData || [])
    setLoading(false)
  }

  async function handleSignOut() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  async function requestUnlock() {
    if (!selectedClient || !unlockReason) {
      alert('Please provide a reason for unlock request')
      return
    }

    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    // Create unlock request
    const { error } = await supabase
      .from('unlock_requests')
      .insert({
        client_id: selectedClient.id,
        requested_by: user.id,
        reason: unlockReason,
        status: 'pending'
      })

    if (error) {
      alert('Error submitting request: ' + error.message)
    } else {
      alert('Unlock request submitted to your admin')
      setShowUnlockModal(false)
      setSelectedClient(null)
      setUnlockReason('')
    }
  }

  if (loading) {
    return <div className="text-center py-10">Loading dashboard...</div>
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Agent Dashboard</h1>
          <p className="text-gray-600">Welcome, {agentName}</p>
        </div>
        <button
          onClick={handleSignOut}
          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
        >
          Sign Out
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-1 gap-4 mb-8">
        <div className="bg-blue-500 text-white rounded-lg p-4">
          <div className="text-sm opacity-90">Clients in Your Group</div>
          <div className="text-3xl font-bold">{clients.length}</div>
        </div>
      </div>

      {/* Clients Table with Unlock Request Button */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-4 py-3 border-b font-semibold">Clients</div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left">Email</th>
                <th className="px-4 py-2 text-left">Consented</th>
                <th className="px-4 py-2 text-left">Paid</th>
                <th className="px-4 py-2 text-left">Form-01</th>
                <th className="px-4 py-2 text-left">Submitted</th>
                <th className="px-4 py-2 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((client) => (
                <tr key={client.id} className="border-t">
                  <td className="px-4 py-2">{client.email}</td>
                  <td className="px-4 py-2">{client.has_consented ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.has_paid ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.onboarding_complete ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.onboarding_submitted ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">
                    <button
                      onClick={() => {
                        setSelectedClient(client)
                        setShowUnlockModal(true)
                      }}
                      className="bg-yellow-600 text-white px-3 py-1 rounded text-sm hover:bg-yellow-700"
                    >
                      Request Unlock
                    </button>
                  </td>
                </tr>
              ))}
              {clients.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-gray-500">
                    No clients assigned to your group yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Unlock Request Modal */}
      {showUnlockModal && selectedClient && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-bold mb-4">Request Form Unlock</h3>
            <p className="mb-2"><strong>Client:</strong> {selectedClient.email}</p>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Reason for unlock request
              </label>
              <textarea
                value={unlockReason}
                onChange={(e) => setUnlockReason(e.target.value)}
                placeholder="Explain why this client needs their forms unlocked..."
                className="w-full border rounded-lg px-3 py-2"
                rows={3}
                required
              />
            </div>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowUnlockModal(false)
                  setSelectedClient(null)
                  setUnlockReason('')
                }}
                className="px-4 py-2 border rounded hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={requestUnlock}
                className="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700"
              >
                Submit Request
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

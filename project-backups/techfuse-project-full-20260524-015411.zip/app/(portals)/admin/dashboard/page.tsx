'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

type Client = {
  id: string
  email: string
  has_consented: boolean
  has_paid: boolean
  onboarding_complete: boolean
  onboarding_submitted: boolean
  created_at: string
}

type UnlockRequest = {
  id: string
  client_id: string
  reason: string
  status: string
  created_at: string
  users?: { email: string }
}

export default function AdminDashboard() {
  const [clients, setClients] = useState<Client[]>([])
  const [unlockRequests, setUnlockRequests] = useState<UnlockRequest[]>([])
  const [selectedRequest, setSelectedRequest] = useState<UnlockRequest | null>(null)
  const [showApproveModal, setShowApproveModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [adminName, setAdminName] = useState('')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    checkAuthAndFetchData()
  }, [])

  async function checkAuthAndFetchData() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('users')
      .select('role, id, email')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'admin') {
      router.push('/client/dashboard')
      return
    }

    setAdminName(profile.email)

    // Get clients assigned to this admin
    const { data: clientsData } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'client')
      .eq('admin_id', profile.id)
      .order('created_at', { ascending: false })

    setClients(clientsData || [])

    // Get pending unlock requests for this admin's clients
    const { data: requests } = await supabase
      .from('unlock_requests')
      .select('*, users!unlock_requests_client_id_fkey(email)')
      .eq('status', 'pending')
      .order('created_at', { ascending: false })

    setUnlockRequests(requests || [])
    setLoading(false)
  }

  async function handleSignOut() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  async function approveUnlock(request: UnlockRequest) {
    // Update unlock request status
    await supabase
      .from('unlock_requests')
      .update({ status: 'approved' })
      .eq('id', request.id)

    // Unlock the form
    await supabase
      .from('generated_forms')
      .update({ is_locked: false })
      .eq('user_id', request.client_id)

    // Refresh data
    await checkAuthAndFetchData()
    setShowApproveModal(false)
    alert('Form unlocked successfully')
  }

  async function denyUnlock(requestId: string) {
    await supabase
      .from('unlock_requests')
      .update({ status: 'denied' })
      .eq('id', requestId)

    await checkAuthAndFetchData()
    alert('Unlock request denied')
  }

  if (loading) {
    return <div className="text-center py-10">Loading dashboard...</div>
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <p className="text-gray-600">Welcome, {adminName}</p>
        </div>
        <button
          onClick={handleSignOut}
          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
        >
          Sign Out
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div className="bg-blue-500 text-white rounded-lg p-4">
          <div className="text-sm opacity-90">Total Clients</div>
          <div className="text-3xl font-bold">{clients.length}</div>
        </div>
        <div className="bg-yellow-500 text-white rounded-lg p-4">
          <div className="text-sm opacity-90">Pending Unlock Requests</div>
          <div className="text-3xl font-bold">{unlockRequests.length}</div>
        </div>
      </div>

      {/* Unlock Requests Section */}
      {unlockRequests.length > 0 && (
        <div className="bg-white rounded-lg shadow mb-8">
          <div className="px-4 py-3 border-b font-semibold bg-yellow-50">
            Pending Unlock Requests
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left">Client</th>
                  <th className="px-4 py-2 text-left">Reason</th>
                  <th className="px-4 py-2 text-left">Requested At</th>
                  <th className="px-4 py-2 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {unlockRequests.map((req) => (
                  <tr key={req.id} className="border-t">
                    <td className="px-4 py-2">{req.users?.email || 'Unknown'}</td>
                    <td className="px-4 py-2">{req.reason}</td>
                    <td className="px-4 py-2">{new Date(req.created_at).toLocaleString()}</td>
                    <td className="px-4 py-2">
                      <button
                        onClick={() => {
                          setSelectedRequest(req)
                          setShowApproveModal(true)
                        }}
                        className="bg-green-600 text-white px-3 py-1 rounded text-sm mr-2 hover:bg-green-700"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => denyUnlock(req.id)}
                        className="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700"
                      >
                        Deny
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Clients Table */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-4 py-3 border-b font-semibold">Assigned Clients</div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left">Email</th>
                <th className="px-4 py-2 text-left">Consented</th>
                <th className="px-4 py-2 text-left">Paid</th>
                <th className="px-4 py-2 text-left">Form-01</th>
                <th className="px-4 py-2 text-left">Submitted</th>
                <th className="px-4 py-2 text-left">Joined</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((client) => (
                <tr key={client.id} className="border-t">
                  <td className="px-4 py-2">{client.email}</td>
                  <td className="px-4 py-2">{client.has_consented ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.has_paid ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.onboarding_complete ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.onboarding_submitted ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{new Date(client.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
              {clients.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-gray-500">
                    No clients assigned yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Approve Modal */}
      {showApproveModal && selectedRequest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-bold mb-4">Approve Unlock Request</h3>
            <p className="mb-2"><strong>Client:</strong> {selectedRequest.users?.email}</p>
            <p className="mb-4"><strong>Reason:</strong> {selectedRequest.reason}</p>
            <p className="mb-4 text-yellow-600">Are you sure you want to unlock this client's form?</p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowApproveModal(false)}
                className="px-4 py-2 border rounded hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => approveUnlock(selectedRequest)}
                className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
              >
                Approve Unlock
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';

export default function PaymentPage() {
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [alreadyPaid, setAlreadyPaid] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  useEffect(() => {
    checkPaymentStatus();
  }, []);

  async function checkPaymentStatus() {
    setLoading(true);
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push('/login');
      return;
    }

    const { data: userData } = await supabase
      .from('users')
      .select('has_paid')
      .eq('id', user.id)
      .single();

    if (userData?.has_paid === true) {
      setAlreadyPaid(true);
    }
    
    setLoading(false);
  }

  async function handlePaymentConfirm() {
    setSaving(true);
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push('/login');
      return;
    }

    // Update user's payment status to true
    const { error } = await supabase
      .from('users')
      .update({ has_paid: true })
      .eq('id', user.id);

    if (error) {
      console.error('Error updating payment status:', error);
      alert('Error processing payment. Please try again.');
      setSaving(false);
      return;
    }

    setSaving(false);
    // Redirect to Form-01 after successful payment
    router.push('/client/form-01');
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // If already paid, show message and allow to continue
  if (alreadyPaid) {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <h1 className="text-2xl font-bold mb-6">Make Payment</h1>
        
        <div className="border rounded-lg p-6 bg-green-50 mb-6">
          <p className="text-green-700">✓ Payment has already been confirmed.</p>
        </div>
        
        <div className="flex gap-4">
          <button
            onClick={() => router.push('/client/select-admin')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            ← Back
          </button>
          <button
            onClick={() => router.push('/client/form-01')}
            className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
          >
            Continue to Form-01 →
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Make Payment</h1>
      
      <div className="border rounded-lg p-6 bg-gray-50 mb-6">
        <h2 className="text-lg font-semibold mb-4">Payment Details</h2>
        <div className="space-y-2 mb-4">
          <p><strong>Amount:</strong> R400.00</p>
          <p><strong>Bank:</strong> Techfuse Consulting</p>
          <p><strong>Account Name:</strong> Techfuse Holdings (Pty) Ltd</p>
          <p><strong>Account Number:</strong> 1234567890</p>
          <p><strong>Branch Code:</strong> 123456</p>
          <p><strong>Reference:</strong> Your Email Address</p>
        </div>
        
        <div className="border-t pt-4 mt-4">
          <p className="text-sm text-gray-600 mb-2">After payment, please confirm below:</p>
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={paymentConfirmed}
              onChange={(e) => setPaymentConfirmed(e.target.checked)}
              className="w-4 h-4"
            />
            <span>I confirm that I have made the payment via EFT, direct bank, or card.</span>
          </label>
        </div>
      </div>
      
      <div className="flex gap-4">
        <button
          onClick={() => router.push('/client/select-admin')}
          className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
        >
          ← Back
        </button>
        <button
          onClick={handlePaymentConfirm}
          disabled={saving || !paymentConfirmed}
          className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
        >
          {saving ? 'Processing...' : 'Confirm Payment →'}
        </button>
      </div>
      
      <div className="mt-6 text-center text-sm text-gray-500">
        <p>After payment, send POP to: payments@techfuseconsulting.online</p>
        <p className="mt-1">Contact support@techfuseconsulting.online for assistance</p>
      </div>
    </div>
  );
}

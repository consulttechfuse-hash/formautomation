'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';

export default function Form07() {
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState<any>(null);
  const router = useRouter();
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      router.push('/login');
      return;
    }

    const { data: form01 } = await supabase
      .from('form01_data')
      .select('*')
      .eq('user_id', session.user.id)
      .single();

    const { data: userData } = await supabase
      .from('users')
      .select('profile_photo_url')
      .eq('id', session.user.id)
      .single();

    let photoImg = '';
    if (userData?.profile_photo_url) {
      photoImg = `<img src="${userData.profile_photo_url}" alt="Profile Photo" style="width:100%;height:100%;object-fit:cover;">`;
    } else {
      photoImg = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#999;font-size:12px;">No photo</div>';
    }

    const { data: template } = await supabase
      .from('form_templates')
      .select('template_html')
      .eq('form_number', 7)
      .single();

    let renderedHtml = '';
    
    if (template && template.template_html) {
      renderedHtml = template.template_html;
      if (form01) {
        Object.keys(form01).forEach(key => {
          const regex = new RegExp(`{{${key}}}`, 'g');
          const value = form01[key] || '';
          renderedHtml = renderedHtml.replace(regex, value);
        });
      }
      const fullName = `${form01?.fn_t1 || ''} ${form01?.mdn_t1 || ''} ${form01?.srn_t1 || ''}`.trim();
      renderedHtml = renderedHtml.replace(/{{full_name}}/g, fullName);
      renderedHtml = renderedHtml.replace(/{{full_name_upper}}/g, fullName.toUpperCase());
      renderedHtml = renderedHtml.replace(/{{current_date}}/g, new Date().toLocaleDateString());
      renderedHtml = renderedHtml.replace(/{{current_year}}/g, new Date().getFullYear().toString());
      renderedHtml = renderedHtml.replace(/{{current_month}}/g, (new Date().getMonth() + 1).toString());
      renderedHtml = renderedHtml.replace(/{{current_day}}/g, new Date().getDate().toString());
      renderedHtml = renderedHtml.replace(/{{profile_picture}}/g, photoImg);
    } else {
      renderedHtml = `
        <h2>Form 07 - Second Witness Testimony</h2>
        <div style="display:flex; gap:20px; margin-bottom:20px;">
          <div style="flex:2;">
            <p>This second Witness Testimony verifies the identity of the Declarant shown in this photograph.</p>
            <p><strong>Name:</strong> ${form01?.fn_t1 || ''} ${form01?.srn_t1 || ''}</p>
          </div>
          <div style="flex:1; text-align:right;">
            <div style="border:1px solid black; width:120px; height:150px; display:flex; align-items:center; justify-content:center;">
              ${photoImg}
            </div>
          </div>
        </div>
        <p>Witness: ___________________________</p>
        <p>Date: ${new Date().toLocaleDateString()}</p>
      `;
    }
    
    setFormData({ html: renderedHtml });
    setLoading(false);
  }

  const handleSubmit = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session && formData) {
      await supabase
        .from('generated_forms')
        .upsert({
          user_id: session.user.id,
          user_email: session.user.email,
          form_number: 7,
          filled_html: formData.html,
          is_locked: false,
          is_submitted: false,
          generated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id,form_number'
        });
    }
    router.push('/forms/08');
  };

  const handleBack = () => {
    router.push('/forms/06');
  };

  if (loading) {
    return <div className="min-h-screen bg-gray-50 py-12 flex justify-center items-center">Loading Form 07...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow">
        <div className="flex justify-between items-center mb-6">
          <button onClick={handleBack} className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">← Back</button>
          <h1 className="text-2xl font-bold">Form 07</h1>
          <button onClick={handleSubmit} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save & Continue →</button>
        </div>
        <div className="prose max-w-none">
          <div dangerouslySetInnerHTML={{ __html: formData?.html || '<p>No data available</p>' }} />
        </div>
      </div>
    </div>
  );
}

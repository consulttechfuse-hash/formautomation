'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import JSZip from 'jszip';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import JumpButton from '@/components/JumpButton';

export default function FormCheckSubmit() {
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [form01Data, setForm01Data] = useState<any>(null);
  const [consentHtml, setConsentHtml] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [allFormsHtml, setAllFormsHtml] = useState<Record<number, string>>({});
  const router = useRouter();
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      router.push('/login');
      return;
    }
    
    const { data: form01 } = await supabase
      .from('form01_data')
      .select('*')
      .eq('user_id', session.user.id)
      .single();
    setForm01Data(form01 || {});
    
    const { data: consentData } = await supabase
      .from('consents')
      .select('html_content')
      .eq('cont_key', 'consent')
      .single();
    
    if (consentData?.html_content) {
      let renderedConsent = consentData.html_content;
      if (form01) {
        Object.keys(form01).forEach(key => {
          const regex = new RegExp(`{{${key}}}`, 'g');
          const value = form01[key] || '';
          renderedConsent = renderedConsent.replace(regex, value);
        });
      }
      setConsentHtml(renderedConsent);
    }
    
    const forms: Record<number, string> = {};
    for (let i = 2; i <= 17; i++) {
      const { data: generated } = await supabase
        .from('generated_forms')
        .select('filled_html')
        .eq('form_number', i)
        .eq('user_id', session.user.id)
        .single();
      
      if (generated?.filled_html) {
        forms[i] = generated.filled_html;
      } else {
        const fullName = `${form01?.fn_t1 || ''} ${form01?.mdn_t1 || ''} ${form01?.srn_t1 || ''}`.trim();
        forms[i] = `
          <h2>Form ${i}</h2>
          <p><strong>Full Name:</strong> ${fullName}</p>
          <p><strong>Email:</strong> ${form01?.ema_t1 || ''}</p>
          <p><strong>Phone:</strong> ${form01?.cnt_1 || ''}</p>
        `;
      }
    }
    setAllFormsHtml(forms);
    setLoading(false);
  }

  async function uploadIDPassport() {
    if (!uploadedFile) return null;
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return null;
    const fileExt = uploadedFile.name.split('.').pop();
    const fileName = `${form01Data?.idp_t1 || form01Data?.fn_t1 || 'user'}-${Date.now()}.${fileExt}`;
    const filePath = `id-documents/${fileName}`;
    const { error: uploadError } = await supabase.storage.from('client-assets').upload(filePath, uploadedFile);
    if (uploadError) return null;
    const { data: { publicUrl } } = supabase.storage.from('client-assets').getPublicUrl(filePath);
    setUploadSuccess(true);
    return publicUrl;
  }

  async function downloadAsZIP() {
    const zip = new JSZip();
    for (let i = 2; i <= 17; i++) {
      zip.file(`form-${String(i).padStart(2, '0')}.html`, allFormsHtml[i] || '');
    }
    const content = await zip.generateAsync({ type: 'blob' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(content);
    link.download = `forms-${form01Data?.fn_t1 || 'user'}-${Date.now()}.zip`;
    link.click();
  }

  async function downloadAllAsPDF() {
    try {
      const pdfDoc = await PDFDocument.create();
      const font = await pdfDoc.embedFont(StandardFonts.TimesRoman);
      
      if (consentHtml) {
        const page = pdfDoc.addPage();
        const { height } = page;
        let y = height - 50;
        page.drawText('CONSENT FORM', { x: 50, y: y, size: 16, font: font });
        y -= 30;
        const consentText = consentHtml.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
        let line = '';
        for (let j = 0; j < consentText.length; j++) {
          line += consentText[j];
          if (line.length > 70 || j === consentText.length - 1) {
            if (y < 50) break;
            page.drawText(line, { x: 50, y: y, size: 10, font: font });
            y -= 15;
            line = '';
          }
        }
        page.drawText('Page 1 of 17', { x: 450, y: 30, size: 8, font: font });
      }
      
      let pageNum = consentHtml ? 2 : 1;
      for (let i = 2; i <= 17; i++) {
        const page = pdfDoc.addPage();
        const { height } = page;
        let y = height - 50;
        page.drawText(`FORM ${i}`, { x: 50, y: y, size: 16, font: font });
        y -= 30;
        const text = (allFormsHtml[i] || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
        let line = '';
        for (let j = 0; j < text.length; j++) {
          line += text[j];
          if (line.length > 70 || j === text.length - 1) {
            if (y < 50) break;
            page.drawText(line, { x: 50, y: y, size: 10, font: font });
            y -= 15;
            line = '';
          }
        }
        page.drawText(`Page ${pageNum} of 17`, { x: 450, y: 30, size: 8, font: font });
        pageNum++;
      }
      
      const pdfBytes = await pdfDoc.save();
      const link = document.createElement('a');
      link.href = URL.createObjectURL(new Blob([pdfBytes], { type: 'application/pdf' }));
      link.download = `all-forms-with-consent-${Date.now()}.pdf`;
      link.click();
    } catch (err) {
      alert('PDF error: ' + err);
    }
  }

  async function downloadAllAsDOCX() {
    try {
      const doc = new Document({ sections: [{ properties: {}, children: [] }] });
      
      for (let i = 2; i <= 17; i++) {
        const text = (allFormsHtml[i] || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
        doc.addSection({
          children: [
            new Paragraph({ children: [new TextRun({ text: `FORM ${i}`, bold: true, size: 32 })] }),
            new Paragraph({ children: [new TextRun({ text: text, size: 24 })] }),
            new Paragraph({ children: [new TextRun({ text: ' ' })] }),
          ],
        });
      }
      
      const blob = await Packer.toBlob(doc);
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `all-forms-${Date.now()}.docx`;
      link.click();
    } catch (err) {
      alert('DOCX error: ' + err);
    }
  }

  async function downloadSinglePDF(formNum: number) {
    try {
      const pdfDoc = await PDFDocument.create();
      const font = await pdfDoc.embedFont(StandardFonts.TimesRoman);
      const page = pdfDoc.addPage();
      const { height } = page;
      let y = height - 50;
      page.drawText(`FORM ${formNum}`, { x: 50, y: y, size: 16, font: font });
      y -= 30;
      const text = (allFormsHtml[formNum] || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
      let line = '';
      for (let j = 0; j < text.length; j++) {
        line += text[j];
        if (line.length > 70 || j === text.length - 1) {
          if (y < 50) break;
          page.drawText(line, { x: 50, y: y, size: 10, font: font });
          y -= 15;
          line = '';
        }
      }
      const pdfBytes = await pdfDoc.save();
      const link = document.createElement('a');
      link.href = URL.createObjectURL(new Blob([pdfBytes], { type: 'application/pdf' }));
      link.download = `form-${String(formNum).padStart(2, '0')}.pdf`;
      link.click();
    } catch (err) {
      alert('PDF error: ' + err);
    }
  }

  async function downloadSingleDOCX(formNum: number) {
    try {
      const text = (allFormsHtml[formNum] || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
      const doc = new Document({
        sections: [{
          properties: {},
          children: [
            new Paragraph({ children: [new TextRun({ text: `FORM ${formNum}`, bold: true, size: 32 })] }),
            new Paragraph({ children: [new TextRun({ text: text, size: 24 })] }),
          ],
        }]
      });
      const blob = await Packer.toBlob(doc);
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `form-${String(formNum).padStart(2, '0')}.docx`;
      link.click();
    } catch (err) {
      alert('DOCX error: ' + err);
    }
  }

  async function handleSubmit() {
    setShowConfirmDialog(true);
  }

  async function confirmSubmit() {
    setShowConfirmDialog(false);
    setSubmitting(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    const idUrl = uploadedFile ? await uploadIDPassport() : null;
    
    if (consentHtml) {
      await supabase.from('generated_forms').upsert({
        user_id: session.user.id,
        user_email: session.user.email,
        form_number: 0,
        filled_html: consentHtml,
        is_locked: true,
        is_submitted: true,
        submitted_at: new Date().toISOString(),
      }, { onConflict: 'user_id,form_number' });
    }
    
    for (let i = 2; i <= 17; i++) {
      await supabase.from('generated_forms').upsert({
        user_id: session.user.id,
        user_email: session.user.email,
        form_number: i,
        filled_html: allFormsHtml[i] || '',
        is_locked: true,
        is_submitted: true,
        submitted_at: new Date().toISOString(),
      }, { onConflict: 'user_id,form_number' });
    }
    
    await supabase.from('users').update({ 
      onboarding_complete: true, 
      onboarding_submitted: true,
      last_completed_form: 17,
      id_document_url: idUrl
    }).eq('id', session.user.id);
    
    setSubmitting(false);
    setSuccessMessage('All forms successfully saved!');
    setTimeout(() => setSuccessMessage(''), 5000);
  }

  if (loading) return <div className="p-12 text-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="bg-white rounded shadow p-6 mb-6">
          <div className="flex justify-between items-center">
            <div className="w-24"></div>
            <JumpButton />
            <div className="w-24"></div>
          </div>
          <h1 className="text-2xl font-bold text-center mt-4">Form Check & Submit</h1>
        </div>
        
        {successMessage && (
          <div className="bg-green-100 border border-green-400 text-green-700 p-3 rounded mb-6">{successMessage}</div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Confirm Your Information</h2>
            <div className="p-3 bg-gray-50 rounded mb-4">
              <p><strong>First Name:</strong> {form01Data?.fn_t1 || '-'}</p>
              <p><strong>Surname:</strong> {form01Data?.srn_t1 || '-'}</p>
              <p><strong>ID/Passport:</strong> {form01Data?.idp_t1 || '-'}</p>
              <p><strong>Email:</strong> {form01Data?.ema_t1 || '-'}</p>
            </div>
            
            <label className="flex items-center gap-3 mb-4">
              <input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} className="w-5 h-5" />
              <span>I confirm all information is correct</span>
            </label>
            
            <div className="mb-4">
              <label className="block font-medium mb-2">Upload ID/Passport</label>
              <input type="file" accept="image/jpeg,image/png" onChange={(e) => setUploadedFile(e.target.files?.[0] || null)} className="w-full border rounded p-2" />
              {uploadSuccess && <p className="text-green-600 text-sm mt-1">Uploaded</p>}
            </div>
            
            <button onClick={handleSubmit} disabled={!confirmed || submitting} className="w-full bg-green-600 text-white py-3 rounded">
              {submitting ? 'Submitting...' : 'Submit All Forms'}
            </button>
          </div>
          
          <div className="bg-white rounded shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Download Options</h2>
            
            <div className="mb-6">
              <h3 className="font-medium mb-2">Bulk Download (All Forms 02-17)</h3>
              <div className="flex gap-2">
                <button onClick={downloadAsZIP} className="bg-blue-600 text-white px-4 py-2 rounded">ZIP</button>
                <button onClick={downloadAllAsPDF} className="bg-blue-600 text-white px-4 py-2 rounded">PDF (includes Consent)</button>
                <button onClick={downloadAllAsDOCX} className="bg-blue-600 text-white px-4 py-2 rounded">DOCX</button>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Individual Forms</h3>
              <div className="grid grid-cols-4 gap-2">
                {[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17].map(n => (
                  <div key={n} className="border rounded p-2 text-center">
                    <div className="text-sm font-medium">Form {n}</div>
                    <div className="flex gap-1 mt-1">
                      <button onClick={() => downloadSinglePDF(n)} className="text-xs bg-blue-500 text-white px-2 py-1 rounded">PDF</button>
                      <button onClick={() => downloadSingleDOCX(n)} className="text-xs bg-blue-500 text-white px-2 py-1 rounded">DOCX</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {consentHtml && (
          <div className="bg-white rounded shadow p-6 mt-6">
            <h2 className="text-xl font-semibold mb-4">Consent Form (Preview)</h2>
            <div className="border rounded p-4 bg-gray-50 max-h-96 overflow-y-auto">
              <div dangerouslySetInnerHTML={{ __html: consentHtml }} />
            </div>
          </div>
        )}
      </div>
      
      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded p-6 max-w-md">
            <h3 className="text-xl font-bold mb-4">Confirm Submission</h3>
            <p className="mb-6">Are you sure? You cannot edit after submission.</p>
            <div className="flex gap-4 justify-end">
              <button onClick={() => setShowConfirmDialog(false)} className="px-4 py-2 border rounded">Cancel</button>
              <button onClick={confirmSubmit} className="px-4 py-2 bg-green-600 text-white rounded">Yes, Submit</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

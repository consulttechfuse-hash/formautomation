'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';

export default function Form09() {
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState<any>(null);
  const [form01Data, setForm01Data] = useState<any>(null);
  const router = useRouter();
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      router.push('/login');
      return;
    }

    const { data: form01, error } = await supabase
      .from('form01_data')
      .select('*')
      .eq('user_id', session.user.id)
      .single();

    if (error) {
      console.error('Error loading Form-01 data:', error);
    }

    setForm01Data(form01 || {});
    
    const { data: template } = await supabase
      .from('form_templates')
      .select('template_html')
      .eq('form_number', 9)
      .single();

    if (template && template.template_html) {
      let renderedHtml = template.template_html;
      if (form01) {
        Object.keys(form01).forEach(key => {
          const regex = new RegExp(`{{${key}}}`, 'g');
          const value = form01[key] || '';
          renderedHtml = renderedHtml.replace(regex, value);
        });
      }
      const fullName = `${form01?.fn_t1 || ''} ${form01?.mdn_t1 || ''} ${form01?.srn_t1 || ''}`.trim();
      renderedHtml = renderedHtml.replace(/{{full_name}}/g, fullName);
      renderedHtml = renderedHtml.replace(/{{full_name_upper}}/g, fullName.toUpperCase());
      renderedHtml = renderedHtml.replace(/{{current_date}}/g, new Date().toLocaleDateString());
      renderedHtml = renderedHtml.replace(/{{current_year}}/g, new Date().getFullYear().toString());
      renderedHtml = renderedHtml.replace(/{{current_month}}/g, (new Date().getMonth() + 1).toString());
      renderedHtml = renderedHtml.replace(/{{current_day}}/g, new Date().getDate().toString());
      
      setFormData({ html: renderedHtml });
    } else {
      setFormData({
        html: `
          <h2>Form 09 - Auto-completed Information</h2>
          <p><strong>Full Name:</strong> ${form01?.fn_t1 || ''} ${form01?.mdn_t1 || ''} ${form01?.srn_t1 || ''}</p>
          <p><strong>Email:</strong> ${form01?.ema_t1 || ''}</p>
          <p><strong>Phone:</strong> ${form01?.cnt_1 || ''}</p>
          <p><strong>Address:</strong> ${form01?.strn_t1 || ''}, ${form01?.ctn_t1 || ''}, ${form01?.spn_t1 || ''}</p>
          <p><strong>Date of Birth:</strong> ${form01?.bdate_t1 || ''}/${form01?.bdate_t2 || ''}/${form01?.bdate_t3 || ''}</p>
        `
      });
    }
    
    setLoading(false);
  }

  const handleSubmit = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session && formData) {
      await supabase
        .from('generated_forms')
        .upsert({
          user_id: session.user.id,
          user_email: session.user.email,
          form_number: 9,
          filled_html: formData.html,
          is_locked: false,
          is_submitted: false,
          generated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id,form_number'
        });
    }
    router.push('/forms/10');
  };

  if (loading) {
    return <div className="min-h-screen bg-gray-50 py-12 flex justify-center items-center">Loading Form 09...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow">
        <div className="mb-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Form 09</h1>
          <span className="text-sm text-gray-500">Form 9 of 17</span>
        </div>
        <div className="prose max-w-none">
          <div dangerouslySetInnerHTML={{ __html: formData?.html || '<p>No data available</p>' }} />
        </div>
        <div className="mt-6 flex justify-end">
          <button 
            onClick={handleSubmit}
            className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
          >
            Save & Continue to Form 10 →
          </button>
        </div>
      </div>
    </div>
  );
}

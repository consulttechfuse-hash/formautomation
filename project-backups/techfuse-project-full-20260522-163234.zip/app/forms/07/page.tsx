'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';
import JumpButton from '@/components/JumpButton';

export default function Form07() {
  const [loading, setLoading] = useState(true);
  const [html, setHtml] = useState('');
  const router = useRouter();
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  useEffect(() => {
    loadForm();
  }, []);

  async function loadForm() {
    setLoading(true);
    
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      router.push('/login');
      return;
    }

    const { data: userData } = await supabase
      .from('users')
      .select('profile_photo_url')
      .eq('id', session.user.id)
      .single();
    
    const { data: form01 } = await supabase
      .from('form01_data')
      .select('*')
      .eq('user_id', session.user.id)
      .single();
    
    const { data: template } = await supabase
      .from('form_templates')
      .select('template_html')
      .eq('form_number', 7)
      .single();
    
    if (template && template.template_html) {
      let rendered = template.template_html;
      
      let photoImg = '';
      if (userData?.profile_photo_url) {
        photoImg = `<img src="${userData.profile_photo_url}" alt="Profile Photo" style="width:100%;height:100%;object-fit:cover;">`;
      } else {
        photoImg = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#999;">No photo</div>';
      }
      rendered = rendered.replace(/{{profile_picture}}/g, photoImg);
      
      if (form01) {
        Object.keys(form01).forEach(key => {
          const regex = new RegExp(`{{${key}}}`, 'g');
          const value = form01[key] || '';
          rendered = rendered.replace(regex, value);
        });
      }
      
      const fullName = `${form01?.fn_t1 || ''} ${form01?.mdn_t1 || ''} ${form01?.srn_t1 || ''}`.trim();
      rendered = rendered.replace(/{{full_name}}/g, fullName);
      rendered = rendered.replace(/{{full_name_upper}}/g, fullName.toUpperCase());
      rendered = rendered.replace(/{{current_date}}/g, new Date().toLocaleDateString());
      rendered = rendered.replace(/{{current_year}}/g, new Date().getFullYear().toString());
      rendered = rendered.replace(/{{current_month}}/g, (new Date().getMonth() + 1).toString());
      rendered = rendered.replace(/{{current_day}}/g, new Date().getDate().toString());
      
      rendered = rendered.replace(/{{wtn2_t1}}/g, form01?.wtn2_t1 || 'Witness Name');
      rendered = rendered.replace(/{{wtn2_t6}}/g, form01?.wtn2_t6 || 'Relationship');
      rendered = rendered.replace(/{{wtn2_t5}}/g, form01?.wtn2_t5 || 'South Africa');
      rendered = rendered.replace(/{{wtn2_t4}}/g, form01?.wtn2_t4 || 'Phone');
      rendered = rendered.replace(/{{wtn2_t3}}/g, form01?.wtn2_t3 || 'email@example.com');
      rendered = rendered.replace(/{{wtn2_t2}}/g, form01?.wtn2_t2 || 'Address');
      rendered = rendered.replace(/{{wtn3_t1}}/g, form01?.wtn3_t1 || 'Witness 3 Name');
      rendered = rendered.replace(/{{wtn3_t2}}/g, form01?.wtn3_t2 || 'Address');
      rendered = rendered.replace(/{{wtn3_t4}}/g, form01?.wtn3_t4 || 'Phone');
      
      setHtml(rendered);
    } else {
      setHtml('<p>Form template not found</p>');
    }
    
    setLoading(false);
  }

  const handleSubmit = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session && html) {
      await supabase
        .from('generated_forms')
        .upsert({
          user_id: session.user.id,
          user_email: session.user.email,
          form_number: 7,
          filled_html: html,
          is_locked: false,
          is_submitted: false,
          generated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id,form_number'
        });
    }
    router.push('/forms/08');
  };

  if (loading) {
    return <div className="min-h-screen bg-gray-50 py-12 flex justify-center items-center">Loading Form 07...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow">
        <div className="flex justify-between items-center mb-6">
          <JumpButton />
          <h1 className="text-2xl font-bold">Form 07</h1>
          <button onClick={handleSubmit} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save & Continue →</button>
        </div>
        <div className="prose max-w-none">
          <div dangerouslySetInnerHTML={{ __html: html }} />
        </div>
      </div>
    </div>
  );
}

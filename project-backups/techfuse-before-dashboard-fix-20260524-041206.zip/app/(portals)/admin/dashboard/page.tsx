'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

type UnlockRequest = {
  id: string
  client_id: string
  requested_by: string
  reason: string
  form_number: number
  status: string
  created_at: string
  agent_email?: string
  client_email?: string
  client_name?: string
}

type Client = {
  id: string
  email: string
  fn_t1?: string
  srn_t1?: string
  idp_t1?: string
  has_consented: boolean
  has_paid: boolean
  onboarding_complete: boolean
  onboarding_submitted: boolean
  admin_id: string | null
  created_at: string
}

type Agent = {
  id: string
  email: string
}

const formOptions = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]

export default function AdminDashboard() {
  const [clients, setClients] = useState<Client[]>([])
  const [agents, setAgents] = useState<Agent[]>([])
  const [unlockRequests, setUnlockRequests] = useState<UnlockRequest[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filterAgent, setFilterAgent] = useState('all')
  const [filterStatus, setFilterStatus] = useState('all')
  const [selectedForm, setSelectedForm] = useState(2)
  const [viewFormData, setViewFormData] = useState(null)
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [showApproveModal, setShowApproveModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [adminName, setAdminName] = useState('')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    checkAuthAndFetchData()
  }, [filterAgent, filterStatus, searchTerm])

  async function checkAuthAndFetchData() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase.from('users').select('role, email').eq('id', user.id).single()
    if (profile?.role !== 'admin') {
      router.push('/client/dashboard')
      return
    }

    setAdminName(profile.email)
    await Promise.all([fetchClients(), fetchAgents(), fetchUnlockRequests()])
    setLoading(false)
  }

  async function handleSignOut() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  async function fetchAgents() {
    const { data } = await supabase.from('users').select('id, email').eq('role', 'agent')
    setAgents(data || [])
  }

  async function fetchClients() {
    const { data: clientsData } = await supabase.from('users').select('*').eq('role', 'client').order('created_at', { ascending: false })
    const clientsWithFormData = await Promise.all((clientsData || []).map(async (client) => {
      const { data: form01 } = await supabase.from('form01_data').select('fn_t1, srn_t1, idp_t1').eq('user_id', client.id).single()
      return { ...client, fn_t1: form01?.fn_t1 || '', srn_t1: form01?.srn_t1 || '', idp_t1: form01?.idp_t1 || '' }
    }))
    filterClients(clientsWithFormData)
  }

  async function fetchUnlockRequests() {
    const { data: requests } = await supabase
      .from('unlock_requests')
      .select(`*, agent:requested_by(email), client:client_id(email, fn_t1, srn_t1)`)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
    
    const formattedRequests = (requests || []).map(req => ({
      ...req,
      agent_email: req.agent?.email,
      client_email: req.client?.email,
      client_name: `${req.client?.fn_t1 || ''} ${req.client?.srn_t1 || ''}`.trim()
    }))
    setUnlockRequests(formattedRequests)
  }

  function filterClients(data = []) {
    let filtered = [...data]
    if (filterAgent !== 'all') filtered = filtered.filter(c => c.admin_id === filterAgent)
    if (filterStatus === 'paid') filtered = filtered.filter(c => c.has_paid === true)
    else if (filterStatus === 'non_paid') filtered = filtered.filter(c => c.has_paid === false)
    else if (filterStatus === 'consented') filtered = filtered.filter(c => c.has_consented === true)
    else if (filterStatus === 'forms_submitted') filtered = filtered.filter(c => c.onboarding_submitted === true)
    if (searchTerm.trim() !== '') {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(c => c.email.toLowerCase().includes(term) || (c.fn_t1 && c.fn_t1.toLowerCase().includes(term)) || (c.srn_t1 && c.srn_t1.toLowerCase().includes(term)) || (c.idp_t1 && c.idp_t1.toLowerCase().includes(term)))
    }
    setClients(filtered)
  }

  async function viewClientForm(client, formNumber) {
    let { data: formData } = await supabase.from('generated_forms').select('filled_html').eq('user_id', client.id).eq('form_number', formNumber).single()
    if (!formData?.filled_html) {
      const { data: template } = await supabase.from('form_templates').select('template_html').eq('form_number', formNumber).single()
      if (template?.template_html) {
        let html = template.template_html
        const { data: form01 } = await supabase.from('form01_data').select('*').eq('user_id', client.id).single()
        if (form01) {
          Object.keys(form01).forEach(key => { const regex = new RegExp(`{{${key}}}`, 'g'); html = html.replace(regex, form01[key] || '') })
        }
        const fullName = `${client.fn_t1 || ''} ${client.srn_t1 || ''}`.trim()
        html = html.replace(/{{full_name}}/g, fullName).replace(/{{current_date}}/g, new Date().toLocaleDateString()).replace(/{{current_year}}/g, new Date().getFullYear().toString()).replace(/{{current_month}}/g, (new Date().getMonth() + 1).toString()).replace(/{{current_day}}/g, new Date().getDate().toString())
        formData = { filled_html: html }
      }
    }
    if (formData?.filled_html) {
      setViewFormData({ html: formData.filled_html, clientName: `${client.fn_t1 || ''} ${client.srn_t1 || ''}`.trim() || client.email, formNumber: formNumber })
    } else {
      alert(`Form ${formNumber} not available for this client.`)
    }
  }

  async function approveUnlock(request) {
    await supabase.from('unlock_requests').update({ status: 'approved' }).eq('id', request.id)
    await supabase.from('generated_forms').update({ is_locked: false }).eq('user_id', request.client_id).eq('form_number', request.form_number)
    await fetchUnlockRequests()
    setShowApproveModal(false)
    alert(`Form ${request.form_number} unlocked for ${request.client_email}`)
  }

  async function denyUnlock(requestId) {
    await supabase.from('unlock_requests').update({ status: 'denied' }).eq('id', requestId)
    await fetchUnlockRequests()
    alert('Unlock request denied')
  }

  function exportToCSV() {
    const headers = ['Name', 'Surname', 'Email', 'ID/Passport', 'Consented', 'Paid', 'Form-01', 'Submitted', 'Created At']
    const rows = clients.map(c => [c.fn_t1 || '', c.srn_t1 || '', c.email, c.idp_t1 || '', c.has_consented ? 'Yes' : 'No', c.has_paid ? 'Yes' : 'No', c.onboarding_complete ? 'Yes' : 'No', c.onboarding_submitted ? 'Yes' : 'No', new Date(c.created_at).toLocaleDateString()])
    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n')
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `clients-export-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  if (loading) return <div className="text-center py-10">Loading dashboard...</div>

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {viewFormData && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center p-4 border-b">
              <div>
                <h2 className="text-xl font-bold">Form {String(viewFormData.formNumber).padStart(2, '0')}</h2>
                <p className="text-sm text-gray-500">Client: {viewFormData.clientName}</p>
              </div>
              <button onClick={() => setViewFormData(null)} className="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div dangerouslySetInnerHTML={{ __html: viewFormData.html }} />
              </div>
            </div>
          </div>
        </div>
      )}

      {showApproveModal && selectedRequest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="text-xl font-bold">Approve Unlock Request</h2>
              <button onClick={() => setShowApproveModal(false)} className="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
            </div>
            <div className="p-4">
              <p><strong>Agent:</strong> {selectedRequest.agent_email}</p>
              <p><strong>Client:</strong> {selectedRequest.client_name || selectedRequest.client_email}</p>
              <p><strong>Form:</strong> {selectedRequest.form_number}</p>
              <p className="mt-2"><strong>Reason:</strong> {selectedRequest.reason}</p>
              <p><strong>Requested:</strong> {new Date(selectedRequest.created_at).toLocaleString()}</p>
              <div className="flex justify-end gap-3 mt-4">
                <button onClick={() => setShowApproveModal(false)} className="px-4 py-2 border rounded">Cancel</button>
                <button onClick={() => approveUnlock(selectedRequest)} className="px-4 py-2 bg-green-600 text-white rounded">Approve Unlock</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <p className="text-gray-600">Welcome, {adminName}</p>
        </div>
        <button onClick={handleSignOut} className="bg-red-600 text-white px-4 py-2 rounded-lg">Sign Out</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-blue-500 text-white rounded-lg p-4">
          <div className="text-sm opacity-90">Total Clients</div>
          <div className="text-3xl font-bold">{clients.length}</div>
        </div>
        <div className="bg-green-500 text-white rounded-lg p-4">
          <div className="text-sm opacity-90">Agents</div>
          <div className="text-3xl font-bold">{agents.length}</div>
        </div>
        <div className="bg-yellow-500 text-white rounded-lg p-4">
          <div className="text-sm opacity-90">Pending Unlock Requests</div>
          <div className="text-3xl font-bold">{unlockRequests.length}</div>
        </div>
      </div>

      {unlockRequests.length > 0 && (
        <div className="bg-white rounded-lg shadow mb-8">
          <div className="px-4 py-3 border-b font-semibold bg-yellow-50">Pending Unlock Requests</div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left">Agent</th>
                  <th className="px-4 py-2 text-left">Client</th>
                  <th className="px-4 py-2 text-left">Form</th>
                  <th className="px-4 py-2 text-left">Reason</th>
                  <th className="px-4 py-2 text-left">Requested At</th>
                  <th className="px-4 py-2 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {unlockRequests.map((req) => (
                  <tr key={req.id} className="border-t">
                    <td className="px-4 py-2">{req.agent_email}</td>
                    <td className="px-4 py-2">{req.client_name || req.client_email}</td>
                    <td className="px-4 py-2">Form {req.form_number}</td>
                    <td className="px-4 py-2">{req.reason.substring(0, 50)}...</td>
                    <td className="px-4 py-2">{new Date(req.created_at).toLocaleString()}</td>
                    <td className="px-4 py-2">
                      <button onClick={() => { setSelectedRequest(req); setShowApproveModal(true); }} className="bg-green-600 text-white px-3 py-1 rounded text-sm mr-2">Approve</button>
                      <button onClick={() => denyUnlock(req.id)} className="bg-red-600 text-white px-3 py-1 rounded text-sm">Deny</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {unlockRequests.length === 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-8">
          <p>No pending unlock requests found.</p>
        </div>
      )}

      <div className="bg-white rounded-lg shadow mb-4 p-4">
        <div className="flex flex-wrap gap-4 items-center justify-between">
          <div className="flex-1 min-w-[200px]">
            <input type="text" placeholder="Search by name, email, or ID/Passport..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full border rounded-lg px-4 py-2" />
          </div>
          <div className="flex gap-4">
            <select value={filterAgent} onChange={(e) => setFilterAgent(e.target.value)} className="border rounded px-2 py-1">
              <option value="all">All Agents</option>
              {agents.map(agent => <option key={agent.id} value={agent.id}>{agent.email}</option>)}
            </select>
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="border rounded px-2 py-1">
              <option value="all">All</option>
              <option value="paid">Paid Only</option>
              <option value="non_paid">Non-Paying</option>
              <option value="consented">Consented Only</option>
              <option value="forms_submitted">Forms Submitted</option>
            </select>
          </div>
          <button onClick={exportToCSV} className="bg-green-600 text-white px-4 py-2 rounded">Export to CSV</button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="px-4 py-3 border-b font-semibold">All Clients</div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left">Name</th>
                <th className="px-4 py-2 text-left">Email</th>
                <th className="px-4 py-2 text-left">ID/Passport</th>
                <th className="px-4 py-2 text-left">Form</th>
                <th className="px-4 py-2 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((client) => (
                <tr key={client.id} className="border-t">
                  <td className="px-4 py-2">{client.fn_t1 || '-'} {client.srn_t1 || '-'}</td>
                  <td className="px-4 py-2">{client.email}</td>
                  <td className="px-4 py-2">{client.idp_t1 || '-'}</td>
                  <td className="px-4 py-2">
                    <select value={selectedForm} onChange={(e) => setSelectedForm(parseInt(e.target.value))} className="border rounded px-2 py-1 text-sm">
                      {formOptions.map(num => <option key={num} value={num}>Form {String(num).padStart(2, '0')}</option>)}
                    </select>
                  </td>
                  <td className="px-4 py-2">
                    <button onClick={() => viewClientForm(client, selectedForm)} className="bg-blue-600 text-white px-3 py-1 rounded text-sm">View Form</button>
                  </td>
                </tr>
              ))}
              {clients.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center py-8 text-gray-500">No clients found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

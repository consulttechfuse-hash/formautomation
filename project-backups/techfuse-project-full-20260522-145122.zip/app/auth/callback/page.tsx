'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

export default function AuthCallbackPage() {
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    handleCallback()
  }, [])

  async function handleCallback() {
    try {
      // Get the session after OAuth/email callback
      const { data: { session }, error: sessionError } = await supabase.auth.getSession()
      
      if (sessionError) {
        console.error('Session error:', sessionError)
        setError(sessionError.message)
        setLoading(false)
        return
      }
      
      if (session?.user) {
        // Check if user has a profile
        const { data: profile, error: profileError } = await supabase
          .from('users')
          .select('role')
          .eq('id', session.user.id)
          .single()
        
        if (profileError && profileError.code === 'PGRST116') {
          // No profile exists, create one for new user
          console.log('Creating profile for new user')
          await supabase
            .from('users')
            .insert({
              id: session.user.id,
              email: session.user.email,
              role: 'client',
              has_consented: false,
              has_paid: false,
              onboarding_complete: false,
              onboarding_submitted: false
            })
        }
        
        const role = profile?.role || 'client'
        
        // Redirect based on role
        if (role === 'owner') router.push('/owner/dashboard')
        else if (role === 'admin') router.push('/admin/dashboard')
        else if (role === 'agent') router.push('/agent/dashboard')
        else router.push('/client/dashboard')
      } else {
        // No session, redirect to login
        router.push('/login')
      }
    } catch (err: any) {
      console.error('Callback error:', err)
      setError(err.message || 'Authentication failed')
      setLoading(false)
    }
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center max-w-md p-6">
          <div className="text-red-600 text-5xl mb-4">⚠️</div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Authentication Failed</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={() => router.push('/login')}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg"
          >
            Try Again
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Completing sign in...</p>
      </div>
    </div>
  )
}

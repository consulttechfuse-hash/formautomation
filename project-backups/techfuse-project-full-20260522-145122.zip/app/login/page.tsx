'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase/client'
import { useRouter, useSearchParams } from 'next/navigation'

export default function LoginPage() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log("Auth state changed:", event, session?.user?.email)
        
        if (event === 'SIGNED_IN' && session?.user) {
          // Fetch user role and redirect
          const { data: profile } = await supabase
            .from('users')
            .select('role')
            .eq('id', session.user.id)
            .single()
          
          const role = profile?.role || 'client'
          
          if (role === 'owner') router.push('/owner/dashboard')
          else if (role === 'admin') router.push('/admin/dashboard')
          else if (role === 'agent') router.push('/agent/dashboard')
          else router.push('/client/dashboard')
        }
      }
    )
    
    // Check existing session
    checkUser()
    
    const errorParam = searchParams.get('error')
    if (errorParam) {
      setError(`Authentication error: ${errorParam}`)
    }
    
    return () => subscription.unsubscribe()
  }, [])

  async function checkUser() {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      
      if (session?.user) {
        const { data: profile } = await supabase
          .from('users')
          .select('role')
          .eq('id', session.user.id)
          .single()
        
        const role = profile?.role || 'client'
        
        if (role === 'owner') router.push('/owner/dashboard')
        else if (role === 'admin') router.push('/admin/dashboard')
        else if (role === 'agent') router.push('/agent/dashboard')
        else router.push('/client/dashboard')
      }
    } catch (err) {
      console.error('Check user error:', err)
    }
  }

  async function handleSignIn(e: React.FormEvent) {
    e.preventDefault()
    if (!email || !password) {
      setError('Please enter both email and password')
      return
    }
    
    setError(null)
    setLoading(true)
    
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: email,
        password: password,
      })
      
      if (error) {
        console.error('Sign in error:', error)
        setError(error.message)
      } else {
        console.log('Sign in successful - waiting for auth state listener')
        // Do NOT redirect here - let the onAuthStateChange handle it
      }
    } catch (err: any) {
      console.error('Unexpected error:', err)
      setError(err.message || 'Failed to sign in')
    } finally {
      setLoading(false)
    }
  }

  async function handleSignUp(e: React.FormEvent) {
    e.preventDefault()
    if (!email || !password) {
      setError('Please enter both email and password')
      return
    }
    
    if (password.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }
    
    setError(null)
    setLoading(true)
    
    try {
      const { data, error } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
          data: {
            full_name: email.split('@')[0],
          }
        }
      })
      
      if (error) {
        console.error('Sign up error:', error)
        setError(error.message)
      } else {
        console.log('Sign up successful', data)
        
        if (data.user) {
          await supabase
            .from('users')
            .upsert({
              id: data.user.id,
              email: email,
              role: 'client',
              has_consented: false,
              has_paid: false,
              onboarding_complete: false,
              onboarding_submitted: false
            })
        }
        
        alert('Account created! Please check your email to confirm, then sign in.')
        setIsSignUp(false)
        setPassword('')
      }
    } catch (err: any) {
      console.error('Unexpected error:', err)
      setError(err.message || 'Failed to sign up')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Techfuse DocControl</h1>
          <p className="text-gray-500 mt-2">
            {isSignUp ? 'Create an account' : 'Sign in to continue'}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm">
            {error}
          </div>
        )}

        <form onSubmit={isSignUp ? handleSignUp : handleSignIn} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={isSignUp ? 'Minimum 6 characters' : 'Enter your password'}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
              minLength={isSignUp ? 6 : undefined}
            />
          </div>
          
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white rounded-lg px-4 py-2 hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {loading ? 'Processing...' : (isSignUp ? 'Sign Up' : 'Sign In')}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => {
              setIsSignUp(!isSignUp)
              setError(null)
              setPassword('')
            }}
            className="text-sm text-blue-600 hover:text-blue-800"
          >
            {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
          </button>
        </div>

        <div className="mt-6 text-center text-xs text-gray-400">
          <p>Questions? Contact support@techfuseconsulting.online</p>
        </div>
      </div>
    </div>
  )
}

'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

export default function AdminDashboard() {
  const [clients, setClients] = useState<any[]>([])
  const [unlockRequests, setUnlockRequests] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    checkAuthAndFetchData()
  }, [])

  async function checkAuthAndFetchData() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('users')
      .select('role, id')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'admin') {
      router.push('/dashboard')
      return
    }

    // Get clients assigned to this admin
    const { data: clientsData } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'client')
      .eq('admin_id', profile.id)

    setClients(clientsData || [])

    // Get unlock requests for this admin's clients
    const { data: requests } = await supabase
      .from('unlock_requests')
      .select('*, users')
      .eq('status', 'pending')

    setUnlockRequests(requests || [])
    setLoading(false)
  }

  async function handleUnlockRequest(requestId: string, approved: boolean) {
    const status = approved ? 'approved' : 'denied'
    
    await supabase
      .from('unlock_requests')
      .update({ status, approved_by_admin_id: (await supabase.auth.getUser()).data.user?.id })
      .eq('id', requestId)

    if (approved) {
      const request = unlockRequests.find(r => r.id === requestId)
      if (request) {
        await supabase
          .from('generated_forms')
          .update({ is_locked: false })
          .eq('user_id', request.client_id)
      }
    }

    // Refresh
    window.location.reload()
  }

  if (loading) {
    return <div className="text-center py-10">Loading...</div>
  }

  const totalPaid = clients.filter(c => c.has_paid).length
  const revenue = totalPaid * 200 // 50% of R400

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-blue-500 text-white rounded-lg p-4">
          <div className="text-sm">Total Clients</div>
          <div className="text-3xl font-bold">{clients.length}</div>
        </div>
        <div className="bg-green-500 text-white rounded-lg p-4">
          <div className="text-sm">Paid Clients</div>
          <div className="text-3xl font-bold">{totalPaid}</div>
        </div>
        <div className="bg-purple-500 text-white rounded-lg p-4">
          <div className="text-sm">Forms Completed</div>
          <div className="text-3xl font-bold">{clients.filter(c => c.onboarding_complete).length}</div>
        </div>
        <div className="bg-red-500 text-white rounded-lg p-4">
          <div className="text-sm">Revenue (50%)</div>
          <div className="text-3xl font-bold">R{revenue}</div>
        </div>
      </div>

      {unlockRequests.length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-8">
          <h2 className="font-semibold mb-3">Pending Unlock Requests</h2>
          {unlockRequests.map((req) => (
            <div key={req.id} className="flex justify-between items-center border-b py-2">
              <div>
                <p className="font-medium">{req.profiles?.email}</p>
                <p className="text-sm text-gray-600">Reason: {req.reason}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleUnlockRequest(req.id, true)} className="bg-green-500 text-white px-3 py-1 rounded">Approve</button>
                <button onClick={() => handleUnlockRequest(req.id, false)} className="bg-red-500 text-white px-3 py-1 rounded">Deny</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="bg-white rounded-lg shadow">
        <div className="px-4 py-3 border-b font-semibold">My Clients</div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left">Email</th>
                <th className="px-4 py-2 text-left">Paid</th>
                <th className="px-4 py-2 text-left">Form-01</th>
                <th className="px-4 py-2 text-left">Submitted</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((client) => (
                <tr key={client.id} className="border-t">
                  <td className="px-4 py-2">{client.email}</td>
                  <td className="px-4 py-2">{client.has_paid ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.onboarding_complete ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.onboarding_submitted ? '✓' : '✗'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

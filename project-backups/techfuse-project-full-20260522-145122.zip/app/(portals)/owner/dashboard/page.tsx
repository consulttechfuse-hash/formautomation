'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

type Stats = {
  totalSignups: number
  totalConsents: number
  totalPaid: number
  totalForm01Complete: number
  totalFormsSubmitted: number
  revenue: number
  abandonedSignins: number
  abandonedPayments: number
}

export default function OwnerDashboard() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [clients, setClients] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    checkAuthAndFetchData()
  }, [])

  async function checkAuthAndFetchData() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'owner') {
      router.push('/dashboard')
      return
    }

    await fetchStats()
    await fetchClients()
    setLoading(false)
  }

  async function fetchStats() {
    // Get all clients (role = client)
    const { data: allClients } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'client')

    const totalSignups = allClients?.length || 0
    const totalConsents = allClients?.filter(c => c.has_consented).length || 0
    const totalPaid = allClients?.filter(c => c.has_paid).length || 0
    const totalForm01Complete = allClients?.filter(c => c.onboarding_complete).length || 0
    const totalFormsSubmitted = allClients?.filter(c => c.onboarding_submitted).length || 0
    const revenue = totalPaid * 200 // 50% of R400 = R200 per client

    setStats({
      totalSignups,
      totalConsents,
      totalPaid,
      totalForm01Complete,
      totalFormsSubmitted,
      revenue,
      abandonedSignins: 0,
      abandonedPayments: 0
    })
  }

  async function fetchClients() {
    const { data } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'client')
      .order('created_at', { ascending: false })

    setClients(data || [])
  }

  if (loading) {
    return <div className="text-center py-10">Loading dashboard...</div>
  }

  const statCards = [
    { title: 'Total Signups', value: stats?.totalSignups, color: 'bg-blue-500' },
    { title: 'Consents Given', value: stats?.totalConsents, color: 'bg-green-500' },
    { title: 'Paid (R400)', value: stats?.totalPaid, color: 'bg-purple-500' },
    { title: 'Form-01 Complete', value: stats?.totalForm01Complete, color: 'bg-yellow-500' },
    { title: 'Forms Submitted', value: stats?.totalFormsSubmitted, color: 'bg-indigo-500' },
    { title: 'Revenue (50%)', value: `R${stats?.revenue}`, color: 'bg-red-500' },
  ]

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Owner Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {statCards.map((card, idx) => (
          <div key={idx} className={`${card.color} text-white rounded-lg p-4`}>
            <div className="text-sm opacity-90">{card.title}</div>
            <div className="text-3xl font-bold">{card.value}</div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-lg shadow">
        <div className="px-4 py-3 border-b font-semibold">All Clients</div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left">Email</th>
                <th className="px-4 py-2 text-left">Consented</th>
                <th className="px-4 py-2 text-left">Paid</th>
                <th className="px-4 py-2 text-left">Form-01</th>
                <th className="px-4 py-2 text-left">Submitted</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((client) => (
                <tr key={client.id} className="border-t">
                  <td className="px-4 py-2">{client.email}</td>
                  <td className="px-4 py-2">{client.has_consented ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.has_paid ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.onboarding_complete ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">{client.onboarding_submitted ? '✓' : '✗'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

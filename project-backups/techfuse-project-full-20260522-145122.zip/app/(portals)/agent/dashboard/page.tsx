'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

export default function AgentDashboard() {
  const [clients, setClients] = useState<any[]>([])
  const [selectedClient, setSelectedClient] = useState<string>('')
  const [unlockReason, setUnlockReason] = useState('')
  const [showUnlockModal, setShowUnlockModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    checkAuthAndFetchData()
  }, [])

  async function checkAuthAndFetchData() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('users')
      .select('role, admin_id')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'agent') {
      router.push('/dashboard')
      return
    }

    // Get clients under the same admin
    const { data: clientsData } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'client')
      .eq('admin_id', profile.admin_id)

    setClients(clientsData || [])
    setLoading(false)
  }

  async function requestUnlock() {
    if (!selectedClient || !unlockReason) {
      alert('Please select a client and provide a reason')
      return
    }

    const { data: { user } } = await supabase.auth.getUser()

    await supabase.from('unlock_requests').insert({
      client_id: selectedClient,
      requested_by_agent_id: user?.id,
      reason: unlockReason,
      status: 'pending'
    })

    setShowUnlockModal(false)
    setSelectedClient('')
    setUnlockReason('')
    alert('Unlock request sent to admin')
  }

  async function sendMessage(clientEmail: string) {
    const message = prompt('Enter your message to the client:')
    if (message) {
      // In a real implementation, send email via Resend
      alert(`Message sent to ${clientEmail}`)
    }
  }

  if (loading) {
    return <div className="text-center py-10">Loading...</div>
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Agent Dashboard</h1>
      
      <div className="bg-white rounded-lg shadow">
        <div className="px-4 py-3 border-b font-semibold flex justify-between items-center">
          <span>My Clients</span>
          <button
            onClick={() => setShowUnlockModal(true)}
            className="bg-yellow-500 text-white px-3 py-1 rounded text-sm"
          >
            Request Unlock
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left">Email</th>
                <th className="px-4 py-2 text-left">Paid</th>
                <th className="px-4 py-2 text-left">Progress</th>
                <th className="px-4 py-2 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((client) => (
                <tr key={client.id} className="border-t">
                  <td className="px-4 py-2">{client.email}</td>
                  <td className="px-4 py-2">{client.has_paid ? '✓' : '✗'}</td>
                  <td className="px-4 py-2">
                    {client.onboarding_submitted ? 'Completed' : 
                     client.onboarding_complete ? 'Form-01 Done' : 
                     client.has_paid ? 'Payment Done' : 'Pending'}
                  </td>
                  <td className="px-4 py-2">
                    <button
                      onClick={() => sendMessage(client.email)}
                      className="text-blue-600 hover:text-blue-800 mr-3"
                    >
                      Message
                    </button>
                    <button
                      onClick={() => {
                        setSelectedClient(client.id)
                        setShowUnlockModal(true)
                      }}
                      disabled={!client.has_paid}
                      className={`text-yellow-600 hover:text-yellow-800 ${!client.has_paid ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      Unlock Request
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Unlock Request Modal */}
      {showUnlockModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Request Form Unlock</h3>
            <select
              value={selectedClient}
              onChange={(e) => setSelectedClient(e.target.value)}
              className="w-full border rounded-lg p-2 mb-4"
            >
              <option value="">Select Client</option>
              {clients.filter(c => c.has_paid).map((client) => (
                <option key={client.id} value={client.id}>{client.email}</option>
              ))}
            </select>
            <textarea
              placeholder="Reason for unlock request..."
              value={unlockReason}
              onChange={(e) => setUnlockReason(e.target.value)}
              className="w-full border rounded-lg p-2 mb-4 h-24"
            />
            <div className="flex gap-3 justify-end">
              <button onClick={() => setShowUnlockModal(false)} className="px-4 py-2 border rounded-lg">Cancel</button>
              <button onClick={requestUnlock} className="px-4 py-2 bg-yellow-500 text-white rounded-lg">Submit Request</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

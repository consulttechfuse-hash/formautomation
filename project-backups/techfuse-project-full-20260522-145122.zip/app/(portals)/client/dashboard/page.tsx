'use client'

import { useEffect, useState } from 'react'
import { createBrowserClient } from '@supabase/ssr'
import { useRouter } from 'next/navigation'

export default function ClientDashboard() {
  const [progress, setProgress] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [retryCount, setRetryCount] = useState(0)
  const router = useRouter()
  
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  useEffect(() => {
    checkProgress()
  }, [retryCount])

  async function checkProgress() {
    console.log("Checking progress, attempt:", retryCount + 1)
    
    // Wait a bit longer for session to be ready
    await new Promise(resolve => setTimeout(resolve, 500))
    
    const { data: { session } } = await supabase.auth.getSession()
    
    console.log("Session:", session?.user?.email)
    
    if (!session) {
      if (retryCount < 3) {
        console.log("No session yet, retrying...")
        setRetryCount(retryCount + 1)
        return
      }
      console.log("No session after 3 retries, redirecting to login")
      router.push('/login')
      return
    }

    const { data: userData, error } = await supabase
      .from('users')
      .select('has_consented, has_paid, onboarding_complete, onboarding_submitted, last_completed_form, admin_id')
      .eq('id', session.user.id)
      .single()

    if (error) {
      console.error('Error fetching user:', error)
    }

    setProgress(userData || {})
    setLoading(false)
  }

  const steps = [
    { id: 1, name: 'Sign up', path: null, completed: true },
    { id: 2, name: 'Sign in', path: null, completed: true },
    { id: 3, name: 'Consent & Declaration', path: '/client/consent', completed: progress?.has_consented === true },
    { id: 4, name: 'Choose Your National Admin', path: '/client/select-admin', completed: progress?.admin_id !== null },
    { id: 5, name: 'Make Payment', path: '/client/payment', completed: progress?.has_paid === true },
    { id: 6, name: 'Complete Form-01', path: '/client/form-01', completed: progress?.onboarding_complete === true },
    { id: 7, name: 'Upload Your Picture', path: '/client/upload-picture', completed: false },
    { id: 8, name: 'Forms 02-17', path: '/client/forms', completed: progress?.onboarding_submitted === true },
  ]

  const currentStep = steps.find(step => step.completed === false && step.path !== null)

  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading Dashboard... (Attempt {retryCount + 1}/3)</div>
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-blue-50 p-4 mb-8 rounded">
        <h1 className="text-2xl font-bold">Welcome to Techfuse DocControl</h1>
        <p>Follow the steps below to complete your application.</p>
      </div>

      <div className="space-y-3">
        {steps.map((step) => (
          <div key={step.id} className="flex items-center justify-between border rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step.completed ? 'bg-green-500 text-white' : 'bg-gray-200'}`}>
                {step.completed ? '✓' : step.id}
              </div>
              <span>{step.name}</span>
            </div>
            {step.path && !step.completed && (
              <button onClick={() => router.push(step.path!)} className="bg-blue-600 text-white px-4 py-1 rounded">
                Start
              </button>
            )}
            {step.completed && <span className="text-green-600">Completed</span>}
          </div>
        ))}
      </div>

      {currentStep && (
        <div className="mt-6 p-4 bg-yellow-50 rounded border border-yellow-200">
          <p className="text-yellow-800">
            <strong>Next step:</strong> {currentStep.name}
          </p>
        </div>
      )}

      <div className="mt-6 text-center text-sm text-gray-600">
        Questions? Contact <a href="mailto:support@techfuseconsulting.online" className="text-blue-600">support@techfuseconsulting.online</a>
      </div>
    </div>
  )
}

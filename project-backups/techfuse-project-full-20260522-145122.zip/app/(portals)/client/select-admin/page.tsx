'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

type Admin = {
  id: string
  user_id: string
  email: string
  role: string
}

export default function SelectAdminPage() {
  const [admins, setAdmins] = useState<Admin[]>([])
  const [selectedAdminId, setSelectedAdminId] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    fetchAdmins()
  }, [])

  async function fetchAdmins() {
    setLoading(true)
    setError(null)
    
    try {
      // Query the user_roles table for users with role = 'admin'
      const { data, error } = await supabase
        .from('user_roles')
        .select('user_id, email, role')
        .eq('role', 'admin')

      if (error) {
        console.error('Error fetching admins:', error)
        setError('Failed to load admins. Please try again.')
        setAdmins([])
      } else {
        console.log('Admins found:', data)
        // Format admins for display
        const formattedAdmins = (data || []).map(admin => ({
          id: admin.user_id,
          user_id: admin.user_id,
          email: admin.email,
          role: admin.role
        }))
        setAdmins(formattedAdmins)
        
        if (formattedAdmins.length === 0) {
          setError('No admins found. Please contact support.')
        }
      }
    } catch (err) {
      console.error('Unexpected error:', err)
      setError('An unexpected error occurred')
    } finally {
      setLoading(false)
    }
  }

  async function handleSelect() {
    if (!selectedAdminId) {
      setError('Please select an admin')
      return
    }

    setSaving(true)
    setError(null)

    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        router.push('/login')
        return
      }

      // Update the client's user_roles record with the selected admin
      const { error: updateError } = await supabase
        .from('user_roles')
        .update({ assigned_admin_id: selectedAdminId })
        .eq('user_id', user.id)

      if (updateError) {
        console.error('Update error:', updateError)
        setError('Failed to assign admin. Please try again.')
        setSaving(false)
        return
      }

      setSaving(false)
      router.push('/client/payment')
      
    } catch (err) {
      console.error('Unexpected error:', err)
      setError('An unexpected error occurred')
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading admins...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Choose Your National Admin</h1>
      
      <p className="text-gray-600 mb-6">
        Please select the admin who will oversee your case. You can contact them directly for support.
      </p>

      {error && (
        <div className="mb-4 p-3 bg-yellow-100 border border-yellow-400 text-yellow-700 rounded-lg">
          {error}
        </div>
      )}

      <div className="mb-8">
        <label className="block font-medium mb-2">Select Admin</label>
        {admins.length === 0 ? (
          <div className="p-4 bg-gray-100 rounded-lg text-gray-600">
            No admins available. Please contact support.
          </div>
        ) : (
          <select
            value={selectedAdminId}
            onChange={(e) => setSelectedAdminId(e.target.value)}
            className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">-- Select an admin --</option>
            {admins.map((admin) => (
              <option key={admin.user_id} value={admin.user_id}>
                {admin.email}
              </option>
            ))}
          </select>
        )}
      </div>

      <button
        onClick={handleSelect}
        disabled={saving || admins.length === 0}
        className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {saving ? 'Saving...' : 'Continue to Payment →'}
      </button>
    </div>
  )
}

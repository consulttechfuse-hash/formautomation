'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

export default function PaymentPage() {
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  async function handleSkipPayment() {
    setLoading(true)
    
    const { data: { user } } = await supabase.auth.getUser()
    
    if (user) {
      // Mark as paid directly in database
      await supabase
        .from('user_roles')
        .update({ has_paid: true })
        .eq('user_id', user.id)
    }
    
    router.push('/client/form-01')
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Payment</h1>
      
      <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 p-4 rounded mb-6">
        ⚠️ Testing Mode - Payment Skipped
      </div>

      <div className="border rounded-lg p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">Demo Bank Details</h2>
        <div className="space-y-2">
          <p><strong>Bank:</strong> Demo Bank</p>
          <p><strong>Account Name:</strong> Techfuse Consulting</p>
          <p><strong>Account Number:</strong> 1234567890</p>
          <p><strong>Amount:</strong> R400.00</p>
        </div>
        <p className="text-sm text-gray-500 mt-4">
          In production, upload your Proof of Payment here.
        </p>
      </div>

      <button
        onClick={handleSkipPayment}
        disabled={loading}
        className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700"
      >
        {loading ? 'Processing...' : 'Skip Payment (Testing Mode) →'}
      </button>
    </div>
  )
}

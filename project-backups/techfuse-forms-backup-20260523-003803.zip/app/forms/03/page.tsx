'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';
import JumpButton from '@/components/JumpButton';

export default function FormPage() {
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState<any>(null);
  const [fullName, setFullName] = useState('');
  const router = useRouter();
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
  
  // Get form number from the URL path
  const pathParts = window.location.pathname.split('/');
  const currentFormNumber = parseInt(pathParts[pathParts.length - 1], 10);

  useEffect(() => {
    async function load() {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.push('/login');
        return;
      }
      
      const { data: form01 } = await supabase
        .from('form01_data')
        .select('*')
        .eq('user_id', session.user.id)
        .single();
      
      setFormData(form01);
      const firstName = form01?.fn_t1 || '';
      const middleName = form01?.mdn_t1 || '';
      const surname = form01?.srn_t1 || '';
      const name = `${firstName} ${middleName} ${surname}`.trim();
      setFullName(name);
      setLoading(false);
    }
    
    load();
  }, []);

  const handleSubmit = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session && formData) {
      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 40px 20px;">
          <h2>Form ${currentFormNumber}</h2>
          <p><strong>Full Name:</strong> ${fullName}</p>
          <p><strong>Email:</strong> ${formData?.ema_t1 || ''}</p>
          <p><strong>Phone:</strong> ${formData?.cnt_1 || ''}</p>
          <p><strong>Submitted:</strong> ${new Date().toLocaleDateString()}</p>
        </div>
      `;
      
      await supabase
        .from('generated_forms')
        .upsert({
          user_id: session.user.id,
          user_email: session.user.email,
          form_number: currentFormNumber,
          filled_html: html,
          is_locked: false,
          is_submitted: false,
          generated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id,form_number'
        });
    }
    
    const nextForm = currentFormNumber + 1;
    if (nextForm <= 17) {
      router.push(`/forms/${String(nextForm).padStart(2, '0')}`);
    } else {
      router.push('/forms/check-submit');
    }
  };

  if (loading) {
    return <div className="p-12 text-center">Loading Form {currentFormNumber}...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow">
        <div className="flex justify-between items-center mb-6">
          <JumpButton />
          <h1 className="text-2xl font-bold">Form {currentFormNumber}</h1>
          <button onClick={handleSubmit} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save & Continue →</button>
        </div>
        
        <div className="prose max-w-none">
          <h2>Form {currentFormNumber} - Auto-completed Information</h2>
          <p><strong>Full Name:</strong> {fullName}</p>
          <p><strong>Email:</strong> {formData?.ema_t1 || ''}</p>
          <p><strong>Phone:</strong> {formData?.cnt_1 || ''}</p>
          <p><strong>Address:</strong> {formData?.strn_t1 || ''}, {formData?.ctn_t1 || ''}</p>
          <p><strong>Date of Birth:</strong> {formData?.bdate_t1 || ''}/{formData?.bdate_t2 || ''}/{formData?.bdate_t3 || ''}</p>
          <hr />
          <p><em>Form data loaded from Form-01. You can review and continue.</em></p>
        </div>
      </div>
    </div>
  );
}

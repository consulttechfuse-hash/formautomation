'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

export default function ConsentPage() {
  const [agreed, setAgreed] = useState(false)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  async function handleAccept() {
    if (!agreed) {
      alert('Please accept the terms')
      return
    }

    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    await supabase.from('consents').insert({
      user_email: user.email,
      agreed: true,
      agreed_at: new Date().toISOString()
    })

    await supabase.from('users').update({ has_consented: true }).eq('id', user.id)

    setLoading(false)
    router.push('/client/select-admin')
  }

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Consent & Declaration</h1>
      <div className="border rounded-lg p-6 bg-gray-50 mb-6 h-96 overflow-y-auto">
        <p>By accepting, you agree to share your private information with Techfuse DocControl and your selected admin.</p>
      </div>
      <label className="flex items-center gap-3 mb-6">
        <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} />
        I agree to the terms
      </label>
      <button onClick={handleAccept} disabled={loading} className="w-full bg-blue-600 text-white py-3 rounded-lg">
        {loading ? 'Processing...' : 'Accept & Continue'}
      </button>
    </div>
  )
}

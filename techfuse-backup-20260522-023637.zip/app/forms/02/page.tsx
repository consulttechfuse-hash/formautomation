'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';

export default function Form02() {
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        router.push('/login');
      }
      setLoading(false);
    });
  }, []);

  const handleSubmit = () => {
    router.push('/forms/03');
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow">
        <h1 className="text-2xl font-bold mb-4">Form 02</h1>
        <p>Form 02 - Auto-completed from Form-01 data</p>
        <button onClick={handleSubmit} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded">
          Continue to Form 03 →
        </button>
      </div>
    </div>
  );
}
